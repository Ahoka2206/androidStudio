package com.example.abueva_portal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //((TextView)findViewById(R.id.id)).setText(response);
    }

    public void clicked(View view) {
        String url = "http://www.hyeumine.com/newuser.php";
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                ((TextView)findViewById(R.id.id)).setText(response);
                ((TextView)findViewById(R.id.ids)).setText(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(">>","Error connecting");
            }
        }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String,String>();

                params.put("firstname",((EditText)findViewById(R.id.fname)).getText().toString());
                params.put("lastname",((EditText)findViewById(R.id.lname)).getText().toString());

                return params;
            }
        };
        queue.add(request);
    }

    public void onclicked(View view) {
        String url = "http://www.hyeumine.com/newnote.php";
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                ((TextView)findViewById(R.id.ids)).setText(response);
                ((TextView)findViewById(R.id.id)).setText(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(">>","Error connecting");
            }
        }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String,String>();

                params.put("id", ((TextView)findViewById(R.id.id)).getText().toString());
                params.put("note",((EditText)findViewById(R.id.note)).getText().toString());

                return params;
            }
        };
        queue.add(request);
    }
}