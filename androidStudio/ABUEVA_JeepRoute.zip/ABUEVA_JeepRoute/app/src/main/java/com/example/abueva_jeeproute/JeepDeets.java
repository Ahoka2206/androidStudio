package com.example.abueva_jeeproute;

public class JeepDeets {
    private int jnum;
    String jname;
    String pos1, pos2, pos3, pos4, pos5;

    public JeepDeets() {
    }

    public JeepDeets(int jnum, String jname, String pos1, String pos2, String pos3, String pos4, String pos5) {
        this.jnum = jnum;
        this.jname = jname;
        this.pos1 = pos1;
        this.pos2 = pos2;
        this.pos3 = pos3;
        this.pos4 = pos4;
        this.pos5 = pos5;
    }

    public int getJnum() {
        return jnum;
    }

    public void setJnum(int jnum) {
        this.jnum = jnum;
    }

    public String getJname() {
        return jname;
    }

    public void setJname(String jname) {
        this.jname = jname;
    }

    public String getPos1() {
        return pos1;
    }

    public void setPos1(String pos1) {
        this.pos1 = pos1;
    }

    public String getPos2() {
        return pos2;
    }

    public void setPos2(String pos2) {
        this.pos2 = pos2;
    }

    public String getPos3() {
        return pos3;
    }

    public void setPos3(String pos3) {
        this.pos3 = pos3;
    }

    public String getPos4() {
        return pos4;
    }

    public void setPos4(String pos4) {
        this.pos4 = pos4;
    }

    public String getPos5() {
        return pos5;
    }

    public void setPos5(String pos5) {
        this.pos5 = pos5;
    }

    @Override
    public String toString() {
        return "JeepDeets{" +
                "jnum=" + jnum +
                ", jname='" + jname + '\'' +
                ", pos1='" + pos1 + '\'' +
                ", pos2='" + pos2 + '\'' +
                ", pos3='" + pos3 + '\'' +
                ", pos4='" + pos4 + '\'' +
                ", pos5='" + pos5 + '\'' +
                '}';
    }

}
