package com.example.abueva_jeeproute;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    String name;
    EditText input;
    TextView output;
    String[] nameList ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.inputJeep);
        output = findViewById(R.id.outputRoute);
    }

    public boolean isJeepCode(String s) {
        char[] ch = s.toCharArray();

        //System.out.println( Character.isDigit(ch[0]));
        //System.out.println( Character.isDigit(ch[1]));
        //System.out.println( Character.isLetter(ch[2]));
        if(Character.isDigit(ch[0]) == true && Character.isDigit(ch[1]) == true && Character.isLetter(ch[2]) == true)
            return true;

        return false;
    }

    public void clicked(View View) {
        name = input.getText().toString().toUpperCase(Locale.ROOT);
        nameList = name.split(",");

        for (int i = 0; i < nameList.length; i++) {
            if(isJeepCode(nameList[i]) == true){
                extractRoutes(nameList[i]);
            }else {
                Toast.makeText(MainActivity.this, "Invalid Jeep Code", Toast.LENGTH_LONG).show();
                input.setText("");
            }
            output.setText(null);
        }

    }

    public void extractRoutes(String jeep) {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://192.168.1.5/JeepRoutes/responseAPIJEEPROUTES.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,  new Response.Listener<String>()  {
            @Override
            public void onResponse(String response) {
                System.out.println(response);
                try {
                    JSONObject jsonArray = new JSONObject(response);
                    JSONObject code = jsonArray.getJSONObject("0");
                    System.out.println(code);

                    String Jcode = code.getString("jeep_name");
                    String pos1 = code.getString("position1");
                    String pos2 = code.getString("position2");
                    String pos3 = code.getString("position3");
                    String pos4 = code.getString("position4");
                    String pos5 = code.getString("position5");

                    String route = (Jcode + " => " +  pos1 + " <-> " + pos2 + " <-> " + pos3 + " <-> " + pos4 + " <-> " + pos5 + "\n");
                    System.out.println(route);

                    output.append(route + "\n");

                }catch (JSONException e){
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("TAG", "onErrorResponse: " + error.getMessage());
            }
        }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String,String>();

                    params.put("jeep_name", jeep);

                return params;
            }
        };
        queue.add(request);
    }

    public void onclear(View view) {
        input.setText(null);
        output.setText(null);
        nameList = null;
    }
}