package com.example.maze;
import java.util.Random;

public class PathRandomizer {
    private Boolean[][] array;

    public PathRandomizer() {
        array = new Boolean[10][10]; //creating a 10x10 matrix
        for(int i = 0; i < 10; i++) {
            for(int j=0; j < 10; j++) {
                array[i][j] = false;
            }
        }
        createPath();
    }

    public void createPath() {
        Random generator = new Random();

        int start = 8; //where you want your path to start

        array[0][start] = true;
        int row = 0;
        int col = start;
        while(array[9][8] != true) { //this is where the path will end which is at the index 8 in the last row

            while(true) {
                int moveRandom = generator.nextInt(4 + 0) + 1;

                if(moveRandom == 0){ //tan awon ang babaw
                    if(row - 1 < 0) { //if statement will check if the previous button/movement was travelled
                        continue;
                    }else {
                        row -= 1;
                    }
                }
                else if(moveRandom == 1) { // left
                    if(col - 1 < 0) {
                        continue;
                    }else {
                        col -= 1;
                    }
                }
                else if(moveRandom == 2) { //ubos
                    if(row + 1 > 9) {
                        continue;
                    }else {
                        row +=1;
                    }
                }
                else if(moveRandom == 3) { // right
                    if(col + 1 > 9) {
                        continue;
                    }else{
                        col += 1;
                    }
                }
                break;
            }
            array[row][col] = true;
        }
    }

    public boolean check(int row, int col) {
        return array[row][col];
    }
}
