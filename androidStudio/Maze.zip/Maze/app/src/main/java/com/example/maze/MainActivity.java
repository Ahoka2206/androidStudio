package com.example.maze;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.annotation.SuppressLint;

public class MainActivity extends AppCompatActivity {
    PathRandomizer newPath = new PathRandomizer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void valid(View v) {
        Button b = (Button) v;
        b.setText("*");
    }

    public void invalid(View v){
        Button b = (Button) v;
        b.setEnabled(false);
    }

    @SuppressLint("NonConstantResourceId")
    public void onClick(View view) {
        Button b = (Button) view;
        switch(b.getId()) { //using switch case to get all button ids
            case R.id.button1:
                if (newPath.check(0, 0))
                    valid(b);
                else
                    invalid(b);
                break;
            case R.id.button2:
                if (newPath.check(0, 1))
                    valid(b);
                else
                    invalid(b);
                    break;
            case R.id.button3: if (newPath.check(0, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button4: if (newPath.check(0, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button5: if (newPath.check(0, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button6: if (newPath.check(0, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button7: if (newPath.check(0, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button8: if (newPath.check(0, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button9: if (newPath.check(0, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button10: if (newPath.check(0, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button11: if (newPath.check(1, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button12: if (newPath.check(1, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button13: if (newPath.check(1, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button14: if (newPath.check(1, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button15: if (newPath.check(1, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button16: if (newPath.check(1, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button17: if (newPath.check(1, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button18: if (newPath.check(1, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button19: if (newPath.check(1, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button20: if (newPath.check(1, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button21: if (newPath.check(2, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button22: if (newPath.check(2, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button23: if (newPath.check(2, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button24: if (newPath.check(2, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button25: if (newPath.check(2, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button26: if (newPath.check(2, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button27: if (newPath.check(2, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button28: if (newPath.check(2, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button29: if (newPath.check(2, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button30: if (newPath.check(2, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button31: if (newPath.check(3, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button32: if (newPath.check(3, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button33: if (newPath.check(3, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button34: if (newPath.check(3, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button35: if (newPath.check(3, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button36: if (newPath.check(3, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button37: if (newPath.check(3, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button38: if (newPath.check(3, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button39: if (newPath.check(3, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button40: if (newPath.check(3, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button41: if (newPath.check(4, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button42: if (newPath.check(4, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button43: if (newPath.check(4, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button44: if (newPath.check(4, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button45: if (newPath.check(4, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button46: if (newPath.check(4, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button47: if (newPath.check(4, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button48: if (newPath.check(4, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button49: if (newPath.check(4, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button50: if (newPath.check(4, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button51: if (newPath.check(5, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button52: if (newPath.check(5, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button53: if (newPath.check(5, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button54: if (newPath.check(5, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button55: if (newPath.check(5, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button56: if (newPath.check(5, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button57: if (newPath.check(5, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button58: if (newPath.check(5, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button59: if (newPath.check(5, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button60: if (newPath.check(5, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button61: if (newPath.check(6, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button62: if (newPath.check(6, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button63: if (newPath.check(6, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button64: if (newPath.check(6, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button65: if (newPath.check(6, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button66: if (newPath.check(6, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button67: if (newPath.check(6, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button68: if (newPath.check(6, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button69: if (newPath.check(6, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button70: if (newPath.check(6, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button71: if (newPath.check(7, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button72: if (newPath.check(7, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button73: if (newPath.check(7, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button74: if (newPath.check(7, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button75: if (newPath.check(7, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button76: if (newPath.check(7, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button77: if (newPath.check(7, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button78: if (newPath.check(7, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button79: if (newPath.check(7, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button80: if (newPath.check(7, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button81: if (newPath.check(8, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button82: if (newPath.check(8, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button83: if (newPath.check(8, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button84: if (newPath.check(8, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button85: if (newPath.check(8, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button86: if (newPath.check(8, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button87: if (newPath.check(8, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button88: if (newPath.check(8, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button89: if (newPath.check(8, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button90: if (newPath.check(8, 9)) { valid(b); } else { invalid(b); }break;
            case R.id.button91: if (newPath.check(9, 0)) { valid(b); } else { invalid(b); }break;
            case R.id.button92: if (newPath.check(9, 1)) { valid(b); } else { invalid(b); }break;
            case R.id.button93: if (newPath.check(9, 2)) { valid(b); } else { invalid(b); }break;
            case R.id.button94: if (newPath.check(9, 3)) { valid(b); } else { invalid(b); }break;
            case R.id.button95: if (newPath.check(9, 4)) { valid(b); } else { invalid(b); }break;
            case R.id.button96: if (newPath.check(9, 5)) { valid(b); } else { invalid(b); }break;
            case R.id.button97: if (newPath.check(9, 6)) { valid(b); } else { invalid(b); }break;
            case R.id.button98: if (newPath.check(9, 7)) { valid(b); } else { invalid(b); }break;
            case R.id.button99: if (newPath.check(9, 8)) { valid(b); } else { invalid(b); }break;
            case R.id.button100: if (newPath.check(9, 9)) { valid(b); } else { invalid(b); }break;
        }
    }
}